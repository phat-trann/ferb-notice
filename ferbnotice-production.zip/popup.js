"use strict";
var NoticeCheckInPopup;
(function (NoticeCheckInPopup) {
    const form = getElementById('settings-form', HTMLFormElement);
    const enabledInput = getElementById('enabled', HTMLInputElement);
    const latestCheckInTimeInput = getElementById('latest-checkin-time', HTMLInputElement);
    const workDurationHoursInput = getElementById('work-duration-hours', HTMLInputElement);
    const roundingSlotMinutesInput = getElementById('rounding-slot-minutes', HTMLSelectElement);
    const todayCheckInTimeInput = getElementById('today-checkin-time', HTMLInputElement);
    const todayCheckInNoteElement = getElementById('today-checkin-note', HTMLParagraphElement);
    const saveButton = getElementById('save-button', HTMLButtonElement);
    const statusElement = getElementById('status', HTMLParagraphElement);
    document.addEventListener('DOMContentLoaded', () => {
        void loadSettings();
    });
    form.addEventListener('submit', (event) => {
        event.preventDefault();
        void saveSettings();
    });
    enabledInput.addEventListener('change', () => {
        void saveEnabledSetting();
    });
    async function loadSettings() {
        setFormBusy(true, 'Đang tải setup...');
        try {
            const response = await sendRuntimeMessage({
                type: 'GET_SETTINGS',
            });
            if (!response.success || !response.settings) {
                throw new Error(response.error ?? 'Không đọc được setup.');
            }
            renderSettings(response.settings);
            renderToday(response.today);
            setStatus('Setup hiện tại đã sẵn sàng.');
        }
        catch (error) {
            setStatus(error instanceof Error ? error.message : 'Không đọc được setup.');
        }
        finally {
            setFormBusy(false);
        }
    }
    async function saveSettings() {
        const nextSettings = readSettingsFromForm();
        const todayCheckInTime = todayCheckInTimeInput.value;
        setFormBusy(true, 'Đang lưu setup...');
        try {
            const response = await sendRuntimeMessage({
                type: 'UPDATE_SETTINGS',
                settings: nextSettings,
            });
            if (!response.success || !response.settings) {
                throw new Error(response.error ?? 'Không lưu được setup.');
            }
            renderSettings(response.settings);
            let today = response.today;
            if (todayCheckInTime) {
                const todayResponse = await sendRuntimeMessage({
                    type: 'UPDATE_TODAY_CHECKIN',
                    checkInTime: todayCheckInTime,
                });
                if (!todayResponse.success) {
                    throw new Error(todayResponse.error ?? 'Không cập nhật được giờ check-in hôm nay.');
                }
                today = todayResponse.today;
            }
            renderToday(today);
            setStatus(todayCheckInTime ? 'Đã lưu setup và cập nhật giờ check-in hôm nay.' : 'Đã lưu setup. Badge sẽ cập nhật ngay.');
        }
        catch (error) {
            setStatus(error instanceof Error ? error.message : 'Không lưu được setup.');
        }
        finally {
            setFormBusy(false);
        }
    }
    async function saveEnabledSetting() {
        setFormBusy(true, enabledInput.checked ? 'Đang bật FerbNotice...' : 'Đang tắt FerbNotice...');
        try {
            const response = await sendRuntimeMessage({
                type: 'UPDATE_SETTINGS',
                settings: {
                    enabled: enabledInput.checked,
                },
            });
            if (!response.success || !response.settings) {
                throw new Error(response.error ?? 'Không cập nhật được trạng thái FerbNotice.');
            }
            renderSettings(response.settings);
            renderToday(response.today);
            setStatus(response.settings.enabled ? 'FerbNotice đã bật.' : 'FerbNotice đã tắt.');
        }
        catch (error) {
            setStatus(error instanceof Error ? error.message : 'Không cập nhật được trạng thái FerbNotice.');
            await loadSettings();
        }
        finally {
            setFormBusy(false);
        }
    }
    function renderSettings(settings) {
        enabledInput.checked = settings.enabled;
        latestCheckInTimeInput.value = settings.latestCheckInTime;
        workDurationHoursInput.value = formatHours(settings.workDurationMinutes);
        roundingSlotMinutesInput.value = String(settings.roundingSlotMinutes);
    }
    function renderToday(today) {
        if (!today || !today.hasCheckIn) {
            todayCheckInTimeInput.value = today?.checkInTime ?? '';
            todayCheckInNoteElement.textContent = 'Chưa check-in hôm nay. Nếu cần set thủ công, nhập giờ thực tế rồi bấm lưu.';
            return;
        }
        todayCheckInTimeInput.value = today.checkInTime ?? '';
        const checkInTime = today.checkInTime ?? 'chưa rõ';
        todayCheckInNoteElement.textContent = today.checkoutReminderDueTime
            ? `Check-in hôm nay: ${checkInTime}. Checkout dự kiến: ${today.checkoutReminderDueTime}.`
            : `Check-in hôm nay: ${checkInTime}.`;
    }
    function readSettingsFromForm() {
        return {
            enabled: enabledInput.checked,
            latestCheckInTime: latestCheckInTimeInput.value,
            workDurationMinutes: Math.round(Number(workDurationHoursInput.value) * 60),
            roundingSlotMinutes: Number(roundingSlotMinutesInput.value),
        };
    }
    function formatHours(minutes) {
        const hours = minutes / 60;
        return Number.isInteger(hours) ? String(hours) : String(Number(hours.toFixed(2)));
    }
    function setFormBusy(isBusy, status) {
        enabledInput.disabled = isBusy;
        latestCheckInTimeInput.disabled = isBusy;
        workDurationHoursInput.disabled = isBusy;
        roundingSlotMinutesInput.disabled = isBusy;
        todayCheckInTimeInput.disabled = isBusy;
        saveButton.disabled = isBusy;
        if (status) {
            setStatus(status);
        }
    }
    function setStatus(status) {
        statusElement.textContent = status;
    }
    function getElementById(id, constructor) {
        const element = document.getElementById(id);
        if (!(element instanceof constructor)) {
            throw new Error(`Missing element: ${id}`);
        }
        return element;
    }
    async function sendRuntimeMessage(message) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage(message, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }
                resolve(response);
            });
        });
    }
})(NoticeCheckInPopup || (NoticeCheckInPopup = {}));
