"use strict";
var NoticeCheckInBackground;
(function (NoticeCheckInBackground) {
    const STORAGE_KEY = 'noticeCheckInState';
    const CHECKOUT_REMINDER_PREFIX = 'checkout-reminder';
    const BADGE_REFRESH_ALARM = 'badge-refresh';
    const EXTENSION_NAME = 'FerbNotice';
    const EXTENSION_CREDIT = 'Made by Ferb';
    const DAY_MS = 24 * 60 * 60 * 1000;
    const RECORD_RETENTION_DAYS = 45;
    const BADGE_REFRESH_PERIOD_MINUTES = 1;
    const LATE_CHECKIN_MESSAGE = 'Trễ giờ check in T.T';
    const DEFAULT_SETTINGS = {
        enabled: true,
        latestCheckInTime: '10:00',
        workDurationMinutes: 9 * 60,
        roundingSlotMinutes: 30,
    };
    const BADGE_TEXT_COLOR = '#ffffff';
    const BADGE_DISABLED_COLOR = '#64748b';
    const BADGE_PENDING_COLOR = '#dc2626';
    const BADGE_COUNTDOWN_COLOR = '#f59e0b';
    const BADGE_READY_COLOR = '#16a34a';
    let operationChain = Promise.resolve();
    chrome.runtime.onInstalled.addListener(() => {
        void queueTask(async () => {
            await initializeState();
            ensureBadgeRefreshAlarm();
            await refreshActionBadge();
        });
    });
    chrome.runtime.onStartup.addListener(() => {
        void queueTask(async () => {
            await initializeState();
            ensureBadgeRefreshAlarm();
            await handleCurrentActiveTab();
            await refreshActionBadge();
        });
    });
    chrome.tabs.onActivated.addListener((activeInfo) => {
        void queueTask(async () => {
            await handleTabActivation(activeInfo.tabId);
            await refreshActionBadge();
        });
    });
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
        if (changeInfo.status !== 'complete' || tab.active !== true) {
            return;
        }
        void queueTask(async () => {
            await handleTabActivation(tabId);
            await refreshActionBadge();
        });
    });
    chrome.windows.onFocusChanged.addListener((windowId) => {
        if (windowId === chrome.windows.WINDOW_ID_NONE) {
            return;
        }
        void queueTask(async () => {
            await handleCurrentActiveTab();
            await refreshActionBadge();
        });
    });
    chrome.alarms.onAlarm.addListener((alarm) => {
        void queueTask(async () => {
            await handleAlarm(alarm);
        });
    });
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
        if (isCompleteCheckInMessage(message)) {
            void queueTask(async () => {
                return completeCheckIn();
            }).then((response) => {
                sendResponse(response);
            }, (error) => {
                console.error('Failed to save check-in', error);
                sendResponse({
                    success: false,
                    error: 'Unable to save your check-in right now.',
                });
            });
            return true;
        }
        if (isGetSettingsMessage(message)) {
            void queueTask(async () => {
                const state = await initializeState();
                return {
                    success: true,
                    settings: state.settings,
                    today: getTodayStatus(state, Date.now()),
                };
            }).then((response) => {
                sendResponse(response);
            }, (error) => {
                console.error('Failed to read settings', error);
                sendResponse({
                    success: false,
                    error: 'Unable to read settings right now.',
                });
            });
            return true;
        }
        if (isUpdateSettingsMessage(message)) {
            void queueTask(async () => {
                return updateSettings(message.settings);
            }).then((response) => {
                sendResponse(response);
            }, (error) => {
                console.error('Failed to update settings', error);
                sendResponse({
                    success: false,
                    error: 'Unable to update settings right now.',
                });
            });
            return true;
        }
        if (isUpdateTodayCheckInMessage(message)) {
            void queueTask(async () => {
                return updateTodayCheckIn(message.checkInTime);
            }).then((response) => {
                sendResponse(response);
            }, (error) => {
                console.error('Failed to update today check-in time', error);
                sendResponse({
                    success: false,
                    error: 'Unable to update today check-in time right now.',
                });
            });
            return true;
        }
        if (isAcknowledgeCheckoutReminderMessage(message)) {
            void queueTask(async () => {
                await acknowledgeCheckoutReminder(message.dayKey);
                return {
                    success: true,
                };
            }).then((response) => {
                sendResponse(response);
            }, (error) => {
                console.error('Failed to acknowledge checkout reminder', error);
                sendResponse({
                    success: false,
                    error: 'Unable to acknowledge checkout reminder right now.',
                });
            });
            return true;
        }
    });
    function queueTask(task) {
        const scheduledTask = operationChain.then(task, task);
        operationChain = scheduledTask.then(() => undefined, () => undefined);
        return scheduledTask;
    }
    async function initializeState() {
        const currentState = await getStorageState();
        const prunedState = pruneState(currentState, Date.now());
        if (prunedState.changed) {
            await saveStorageState(prunedState.state);
        }
        return prunedState.state;
    }
    async function handleCurrentActiveTab() {
        const activeTab = await getCurrentActiveTab();
        if (!activeTab || typeof activeTab.id !== 'number') {
            return;
        }
        await handleTabActivation(activeTab.id);
    }
    async function handleTabActivation(tabId) {
        const tab = await getTab(tabId);
        if (!tab || typeof tab.id !== 'number' || !isInjectableUrl(tab.url)) {
            return;
        }
        const state = await initializeState();
        if (!state.settings.enabled) {
            return;
        }
        const now = Date.now();
        const pendingReminder = getPendingCheckoutReminder(state, now);
        if (pendingReminder) {
            const reminderShown = await showCheckoutReminder(tab.id, pendingReminder);
            if (reminderShown) {
                pendingReminder.checkoutReminderShownAt = now;
                state.records[pendingReminder.dayKey] = pendingReminder;
                await saveStorageState(state);
            }
            return;
        }
        const activeWorkRecord = getActiveWorkRecord(state, now);
        if (activeWorkRecord) {
            return;
        }
        const dayKey = getDayKey(now);
        const todayRecord = state.records[dayKey];
        if (todayRecord?.checkInAt || todayRecord?.promptShownAt) {
            return;
        }
        const promptShown = await showDailyCheckInPrompt(tab.id, dayKey, state.settings);
        if (!promptShown) {
            return;
        }
        state.records[dayKey] = {
            dayKey,
            promptShownAt: now,
        };
        await saveStorageState(state);
    }
    async function handleAlarm(alarm) {
        if (alarm.name === BADGE_REFRESH_ALARM) {
            await refreshActionBadge();
            return;
        }
        const dayKey = parseAlarmDayKey(alarm.name);
        if (!dayKey) {
            return;
        }
        const state = await initializeState();
        if (!state.settings.enabled) {
            await refreshActionBadge();
            return;
        }
        const record = state.records[dayKey];
        if (!record || !record.checkInAt || !record.checkoutReminderDueAt || record.checkoutReminderShownAt) {
            await refreshActionBadge();
            return;
        }
        const activeTab = await getCurrentActiveTab();
        if (!activeTab || typeof activeTab.id !== 'number' || !isInjectableUrl(activeTab.url)) {
            await refreshActionBadge();
            return;
        }
        const reminderShown = await showCheckoutReminder(activeTab.id, record);
        if (!reminderShown) {
            await refreshActionBadge();
            return;
        }
        record.checkoutReminderShownAt = Date.now();
        state.records[dayKey] = record;
        await saveStorageState(state);
        await refreshActionBadge();
    }
    async function completeCheckIn() {
        const now = Date.now();
        const dayKey = getDayKey(now);
        const state = await initializeState();
        const record = state.records[dayKey] ?? { dayKey };
        const isLate = isLateCheckInTime(now, state.settings);
        const checkoutReminderDueAt = roundCheckoutReminderTime(now + minutesToMilliseconds(state.settings.workDurationMinutes), state.settings.roundingSlotMinutes);
        record.promptShownAt = record.promptShownAt ?? now;
        record.checkInAt = now;
        record.checkoutReminderDueAt = checkoutReminderDueAt;
        delete record.checkoutReminderShownAt;
        state.records[dayKey] = record;
        await saveStorageState(state);
        await clearAlarm(getAlarmName(dayKey));
        if (record.checkoutReminderDueAt > now) {
            chrome.alarms.create(getAlarmName(dayKey), {
                when: record.checkoutReminderDueAt,
            });
        }
        ensureBadgeRefreshAlarm();
        await refreshActionBadge();
        return {
            success: true,
            dueAt: record.checkoutReminderDueAt,
            isLate,
            lateMessage: isLate ? LATE_CHECKIN_MESSAGE : undefined,
        };
    }
    async function acknowledgeCheckoutReminder(dayKey) {
        const state = await initializeState();
        const record = state.records[dayKey];
        if (record?.checkInAt && record.checkoutReminderDueAt && !record.checkoutReminderShownAt) {
            record.checkoutReminderShownAt = Date.now();
            state.records[dayKey] = record;
            await saveStorageState(state);
        }
        await refreshActionBadge();
    }
    async function updateSettings(settingsPatch) {
        const state = await initializeState();
        const nextSettings = normalizeSettings({
            ...state.settings,
            ...settingsPatch,
        });
        state.settings = nextSettings;
        await saveStorageState(state);
        await refreshActionBadge();
        return {
            success: true,
            settings: nextSettings,
            today: getTodayStatus(state, Date.now()),
        };
    }
    async function updateTodayCheckIn(checkInTime) {
        if (!isTimeInput(checkInTime)) {
            return {
                success: false,
                error: 'Giờ check-in hôm nay không hợp lệ.',
            };
        }
        const now = Date.now();
        const dayKey = getDayKey(now);
        const state = await initializeState();
        const record = state.records[dayKey] ?? { dayKey };
        const checkInAt = getLocalTimeTimestamp(now, checkInTime);
        const checkoutReminderDueAt = roundCheckoutReminderTime(checkInAt + minutesToMilliseconds(state.settings.workDurationMinutes), state.settings.roundingSlotMinutes);
        const previousCheckoutReminderDueAt = record.checkoutReminderDueAt;
        record.promptShownAt = record.promptShownAt ?? now;
        record.checkInAt = checkInAt;
        record.checkoutReminderDueAt = checkoutReminderDueAt;
        if (previousCheckoutReminderDueAt !== checkoutReminderDueAt) {
            delete record.checkoutReminderShownAt;
        }
        state.records[dayKey] = record;
        await saveStorageState(state);
        await clearAlarm(getAlarmName(dayKey));
        if (record.checkoutReminderDueAt > now) {
            chrome.alarms.create(getAlarmName(dayKey), {
                when: record.checkoutReminderDueAt,
            });
        }
        ensureBadgeRefreshAlarm();
        await refreshActionBadge();
        return {
            success: true,
            today: getTodayStatus(state, now),
        };
    }
    function getPendingCheckoutReminder(state, now) {
        const pendingRecords = Object.values(state.records)
            .filter((record) => {
            return Boolean(record.checkInAt && record.checkoutReminderDueAt && record.checkoutReminderDueAt <= now && !record.checkoutReminderShownAt);
        })
            .sort((leftRecord, rightRecord) => {
            return (leftRecord.checkoutReminderDueAt ?? 0) - (rightRecord.checkoutReminderDueAt ?? 0);
        });
        return pendingRecords[0] ?? null;
    }
    function getActiveWorkRecord(state, now) {
        const activeRecords = Object.values(state.records)
            .filter((record) => {
            return Boolean(record.checkInAt && record.checkoutReminderDueAt && record.checkoutReminderDueAt > now);
        })
            .sort((leftRecord, rightRecord) => {
            return (rightRecord.checkInAt ?? 0) - (leftRecord.checkInAt ?? 0);
        });
        return activeRecords[0] ?? null;
    }
    function getTodayStatus(state, now) {
        const dayKey = getDayKey(now);
        const record = state.records[dayKey];
        return {
            dayKey,
            hasCheckIn: Boolean(record?.checkInAt),
            checkInTime: typeof record?.checkInAt === 'number' ? formatTimeInput(record.checkInAt) : undefined,
            checkoutReminderDueTime: typeof record?.checkoutReminderDueAt === 'number' ? formatTimeInput(record.checkoutReminderDueAt) : undefined,
        };
    }
    async function refreshActionBadge() {
        const state = await initializeState();
        const badgeState = getBadgeState(state, Date.now());
        await Promise.all([chrome.action.setBadgeText({ text: badgeState.text }), chrome.action.setBadgeBackgroundColor({ color: badgeState.backgroundColor }), chrome.action.setBadgeTextColor({ color: BADGE_TEXT_COLOR }), chrome.action.setTitle({ title: badgeState.title })]);
    }
    function getBadgeState(state, now) {
        if (!state.settings.enabled) {
            return {
                text: 'OFF',
                backgroundColor: BADGE_DISABLED_COLOR,
                title: withExtensionCredit('Reminder đang tắt. Bấm icon để bật lại.'),
            };
        }
        const activeWorkRecord = getActiveWorkRecord(state, now);
        if (activeWorkRecord?.checkInAt && activeWorkRecord.checkoutReminderDueAt) {
            const remainingMs = activeWorkRecord.checkoutReminderDueAt - now;
            return {
                text: formatBadgeCountdown(remainingMs),
                backgroundColor: BADGE_COUNTDOWN_COLOR,
                title: withExtensionCredit(`Check in: ${formatTime(activeWorkRecord.checkInAt)}.\nCòn ${formatDuration(remainingMs)}.\nĐủ giờ: ${formatTime(activeWorkRecord.checkoutReminderDueAt)}.`),
            };
        }
        const todayRecord = state.records[getDayKey(now)];
        if (todayRecord?.checkInAt && todayRecord.checkoutReminderDueAt && todayRecord.checkoutReminderDueAt <= now) {
            return {
                text: 'OUT',
                backgroundColor: BADGE_READY_COLOR,
                title: withExtensionCredit(`Đã đủ 9 giờ.\nNhớ checkout trước khi ra về.\nCheck in: ${formatTime(todayRecord.checkInAt)}.\nĐủ giờ: ${formatTime(todayRecord.checkoutReminderDueAt)}.`),
            };
        }
        const lateSuffix = isLateCheckInTime(now, state.settings) ? ` ${LATE_CHECKIN_MESSAGE}` : '';
        return {
            text: 'IN?',
            backgroundColor: BADGE_PENDING_COLOR,
            title: withExtensionCredit(`Chưa check in hôm nay.${lateSuffix}`),
        };
    }
    async function showDailyCheckInPrompt(tabId, dayKey, settings) {
        const now = Date.now();
        const isLate = isLateCheckInTime(now, settings);
        const message = {
            type: 'SHOW_DAILY_CHECKIN_PROMPT',
            dayKey,
            isLate,
            lateMessage: isLate ? LATE_CHECKIN_MESSAGE : undefined,
        };
        return showNotice(tabId, message);
    }
    async function showCheckoutReminder(tabId, record) {
        if (!record.checkInAt || !record.checkoutReminderDueAt) {
            return false;
        }
        const message = {
            type: 'SHOW_CHECKOUT_REMINDER',
            dayKey: record.dayKey,
            checkInAt: record.checkInAt,
            dueAt: record.checkoutReminderDueAt,
        };
        return showNotice(tabId, message);
    }
    async function showNotice(tabId, message) {
        const scriptInjected = await injectContentScript(tabId);
        if (!scriptInjected) {
            return false;
        }
        return sendMessageToTab(tabId, message);
    }
    async function injectContentScript(tabId) {
        return new Promise((resolve) => {
            chrome.scripting.executeScript({
                target: { tabId },
                files: ['content.js'],
            }, () => {
                if (chrome.runtime.lastError) {
                    resolve(false);
                    return;
                }
                resolve(true);
            });
        });
    }
    async function sendMessageToTab(tabId, message) {
        return new Promise((resolve) => {
            chrome.tabs.sendMessage(tabId, message, () => {
                if (chrome.runtime.lastError) {
                    resolve(false);
                    return;
                }
                resolve(true);
            });
        });
    }
    function getAlarmName(dayKey) {
        return `${CHECKOUT_REMINDER_PREFIX}:${dayKey}`;
    }
    function parseAlarmDayKey(alarmName) {
        if (!alarmName.startsWith(`${CHECKOUT_REMINDER_PREFIX}:`)) {
            return null;
        }
        const dayKey = alarmName.slice(CHECKOUT_REMINDER_PREFIX.length + 1);
        return dayKey || null;
    }
    function pruneState(state, now) {
        const cutoffDayKey = getDayKey(now - RECORD_RETENTION_DAYS * DAY_MS);
        const nextRecords = {};
        let changed = false;
        Object.entries(state.records).forEach(([dayKey, record]) => {
            if (dayKey >= cutoffDayKey) {
                nextRecords[dayKey] = record;
                return;
            }
            changed = true;
        });
        return {
            state: {
                version: 1,
                records: nextRecords,
                settings: state.settings,
            },
            changed,
        };
    }
    function getDayKey(timestamp) {
        const date = new Date(timestamp);
        const year = String(date.getFullYear());
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    function isLateCheckInTime(timestamp, settings) {
        return timestamp > getLocalTimeTimestamp(timestamp, settings.latestCheckInTime);
    }
    function getLocalTimeTimestamp(timestamp, time) {
        const date = new Date(timestamp);
        const [hours, minutes] = time.split(':').map((value) => Number(value));
        date.setHours(hours, minutes, 0, 0);
        return date.getTime();
    }
    function roundCheckoutReminderTime(timestamp, roundingSlotMinutes) {
        const date = new Date(timestamp);
        const currentMinutes = date.getMinutes();
        const currentSeconds = date.getSeconds();
        const currentMilliseconds = date.getMilliseconds();
        const remainderMinutes = currentMinutes % roundingSlotMinutes;
        const isExactlyOnSlot = remainderMinutes === 0 && currentSeconds === 0 && currentMilliseconds === 0;
        if (isExactlyOnSlot) {
            return date.getTime();
        }
        if (remainderMinutes === 0) {
            date.setMinutes(currentMinutes + roundingSlotMinutes, 0, 0);
            return date.getTime();
        }
        date.setMinutes(currentMinutes + (roundingSlotMinutes - remainderMinutes), 0, 0);
        return date.getTime();
    }
    function minutesToMilliseconds(minutes) {
        return minutes * 60 * 1000;
    }
    function formatBadgeCountdown(remainingMs) {
        const totalMinutes = Math.max(0, Math.ceil(remainingMs / (60 * 1000)));
        if (totalMinutes >= 60) {
            return `${Math.floor(totalMinutes / 60)}h`;
        }
        return `${totalMinutes}m`;
    }
    function formatDuration(remainingMs) {
        const totalMinutes = Math.max(0, Math.ceil(remainingMs / (60 * 1000)));
        const hours = Math.floor(totalMinutes / 60);
        const minutes = totalMinutes % 60;
        if (hours === 0) {
            return `${minutes} phút`;
        }
        if (minutes === 0) {
            return `${hours} giờ`;
        }
        return `${hours} giờ ${minutes} phút`;
    }
    function formatTime(timestamp) {
        return new Intl.DateTimeFormat('vi-VN', {
            hour: '2-digit',
            minute: '2-digit',
        }).format(new Date(timestamp));
    }
    function formatTimeInput(timestamp) {
        const date = new Date(timestamp);
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        return `${hours}:${minutes}`;
    }
    function ensureBadgeRefreshAlarm() {
        chrome.alarms.create(BADGE_REFRESH_ALARM, {
            periodInMinutes: BADGE_REFRESH_PERIOD_MINUTES,
        });
    }
    function withExtensionCredit(message) {
        return `${EXTENSION_NAME} • ${EXTENSION_CREDIT}\n${message}`;
    }
    function isInjectableUrl(url) {
        if (!url) {
            return false;
        }
        return url.startsWith('http://') || url.startsWith('https://') || url.startsWith('file://');
    }
    function isCompleteCheckInMessage(message) {
        return isRecord(message) && message.type === 'COMPLETE_CHECKIN';
    }
    function isGetSettingsMessage(message) {
        return isRecord(message) && message.type === 'GET_SETTINGS';
    }
    function isUpdateSettingsMessage(message) {
        return isRecord(message) && message.type === 'UPDATE_SETTINGS' && isRecord(message.settings);
    }
    function isUpdateTodayCheckInMessage(message) {
        return isRecord(message) && message.type === 'UPDATE_TODAY_CHECKIN' && typeof message.checkInTime === 'string';
    }
    function isAcknowledgeCheckoutReminderMessage(message) {
        return isRecord(message) && message.type === 'ACKNOWLEDGE_CHECKOUT_REMINDER' && typeof message.dayKey === 'string';
    }
    function isRecord(value) {
        return typeof value === 'object' && value !== null;
    }
    async function getStorageState() {
        return new Promise((resolve) => {
            chrome.storage.local.get(STORAGE_KEY, (items) => {
                if (chrome.runtime.lastError) {
                    console.error('Failed to read extension state', chrome.runtime.lastError);
                    resolve(createEmptyState());
                    return;
                }
                resolve(normalizeState(items[STORAGE_KEY]));
            });
        });
    }
    async function saveStorageState(state) {
        return new Promise((resolve, reject) => {
            chrome.storage.local.set({
                [STORAGE_KEY]: state,
            }, () => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }
                resolve();
            });
        });
    }
    async function clearAlarm(alarmName) {
        return new Promise((resolve) => {
            chrome.alarms.clear(alarmName, (wasCleared) => {
                if (chrome.runtime.lastError) {
                    resolve(false);
                    return;
                }
                resolve(wasCleared);
            });
        });
    }
    async function getCurrentActiveTab() {
        const tabs = await queryTabs({
            active: true,
            lastFocusedWindow: true,
        });
        return tabs[0] ?? null;
    }
    async function queryTabs(queryInfo) {
        return new Promise((resolve) => {
            chrome.tabs.query(queryInfo, (tabs) => {
                if (chrome.runtime.lastError) {
                    resolve([]);
                    return;
                }
                resolve(tabs);
            });
        });
    }
    async function getTab(tabId) {
        return new Promise((resolve) => {
            chrome.tabs.get(tabId, (tab) => {
                if (chrome.runtime.lastError) {
                    resolve(null);
                    return;
                }
                resolve(tab);
            });
        });
    }
    function createEmptyState() {
        return {
            version: 1,
            records: {},
            settings: DEFAULT_SETTINGS,
        };
    }
    function normalizeState(candidate) {
        if (!isRecord(candidate) || candidate.version !== 1 || !isRecord(candidate.records)) {
            return createEmptyState();
        }
        const records = {};
        Object.entries(candidate.records).forEach(([dayKey, value]) => {
            const normalizedRecord = normalizeRecord(dayKey, value);
            if (normalizedRecord) {
                records[dayKey] = normalizedRecord;
            }
        });
        return {
            version: 1,
            records,
            settings: normalizeSettings(candidate.settings),
        };
    }
    function normalizeSettings(candidate) {
        if (!isRecord(candidate)) {
            return DEFAULT_SETTINGS;
        }
        return {
            enabled: typeof candidate.enabled === 'boolean' ? candidate.enabled : DEFAULT_SETTINGS.enabled,
            latestCheckInTime: normalizeTimeInput(candidate.latestCheckInTime),
            workDurationMinutes: normalizeIntegerInput(candidate.workDurationMinutes, 30, 24 * 60, DEFAULT_SETTINGS.workDurationMinutes),
            roundingSlotMinutes: normalizeIntegerInput(candidate.roundingSlotMinutes, 1, 120, DEFAULT_SETTINGS.roundingSlotMinutes),
        };
    }
    function normalizeTimeInput(candidate) {
        if (isTimeInput(candidate)) {
            return candidate;
        }
        return DEFAULT_SETTINGS.latestCheckInTime;
    }
    function isTimeInput(candidate) {
        return typeof candidate === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(candidate);
    }
    function normalizeIntegerInput(candidate, min, max, fallback) {
        if (typeof candidate !== 'number' || !Number.isFinite(candidate)) {
            return fallback;
        }
        const normalizedValue = Math.round(candidate);
        return Math.min(max, Math.max(min, normalizedValue));
    }
    function normalizeRecord(dayKey, candidate) {
        if (!isRecord(candidate)) {
            return null;
        }
        const record = {
            dayKey,
        };
        if (typeof candidate.promptShownAt === 'number') {
            record.promptShownAt = candidate.promptShownAt;
        }
        if (typeof candidate.checkInAt === 'number') {
            record.checkInAt = candidate.checkInAt;
        }
        if (typeof candidate.checkoutReminderDueAt === 'number') {
            record.checkoutReminderDueAt = candidate.checkoutReminderDueAt;
        }
        if (typeof candidate.checkoutReminderShownAt === 'number') {
            record.checkoutReminderShownAt = candidate.checkoutReminderShownAt;
        }
        return record;
    }
})(NoticeCheckInBackground || (NoticeCheckInBackground = {}));
